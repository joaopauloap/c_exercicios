#include <windows.h>
int main(){
MoveFile("c:\\exemplo.txt","c:\\windows\\copia.txt");
//arquivo a ser movido, onde guardar 
return 0;
}
