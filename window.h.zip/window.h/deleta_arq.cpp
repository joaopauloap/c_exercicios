#include <windows.h>
int main()
{
DeleteFile("c:\\exemplo.txt");
//arq a ser deletado
return 0;
}
