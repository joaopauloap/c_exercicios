#include <windows.h>
int main(){
CopyFile("c:\\exemplo.txt","c:\\windows\\copia.txt",0);
//arquivo a ser copiado, onde guardar o arquivo
return 0;
}
